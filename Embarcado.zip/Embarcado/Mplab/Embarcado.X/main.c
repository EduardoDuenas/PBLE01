#include"pic18f4520.h"
#include"adc.h"
#include"lcd.h"
#include"rtc.h"
#include"pwm.h"
#include<stdlib.h>

void ZerarFlags();
void LimpaTela();
void TesteAN();
void TestePWM();
void MenuSwitch();
void TesteRTC();
void TesteLEDS();
void TesteBAS();
void RepeteMenu();
void Menu();
void KpRead();
void Delay_ms(unsigned char i);
void delayms(int t);

//Var. Globais do Teclado

unsigned char teste1[] = "B0 = Teste LEDS " ;
unsigned char teste2[] = "B1 = Teste RTC  ";
unsigned char teste3[] = "B2 = Teste PWM  ";
unsigned char teste4[] = "B3 = Teste AN   ";
unsigned char final1[] = "  T1=B0  T2=B1  ";
unsigned char final2[] = "  T3=B2  T4=B3  ";
unsigned char limpaum[] = "                ";
unsigned char limpadois[] = "                ";
unsigned char conversaoad[] = "Conversao AD    ";

int read    = 0x00;
int readAD  = 0x00;

unsigned char butt01 = 0x00,                    
              butt02 = 0x00, 
              butt03 = 0x00,                   
              butt04 = 0x00, 
              butt05 = 0x00, 
              flagAux = 0x00,
              botao = 0x00;

char    testbutt = 0x00;
char    i = 0x00;
//unsigned char    txtAD[4] =  (readADmil,readADcent,readADdez,readADuni);

//Var. Globais do LCD

void main() {
    
    lcdInit();
    Menu();
    
    while(1){
        while (botao == 0){
        KpRead();   
        }
        switch(botao){
            case 01 : TesteLEDS(); break;
            case 02 : TesteRTC();  break; 
            case 03 : TestePWM();  break;
            case 04 : TesteAN();   break;
            case 05 : TesteBAS();  break;
            
            default : KpRead();
        }   
    }
}


void TesteAN(){
       
    ADCON0 = 0x01;       //seleciona o canal 0 e liga o ad
	ADCON1 = 0b00001001; //AN0 � analogico, a referencia � baseada na fonte
	ADCON2 = 0b10101010; //FOSC /32, Alinhamento � direita e tempo de conv = 12 TAD
    
    TRISA = 0xF7;
    TRISB = 0xEF;
    TRISC = 0xFC;
    
    /*
     0.8 x 204,8 = 163,84
     1.6 x 204,8 = 327,68
     2.4 x 204,8 = 491,52
     3.0 x 204,8 = 614,40
     */
    
    LimpaTela();
            
    while (butt04 == 1){
        
        readAD = adcRead();
        
    if      (readAD > 133 && readAD < 193){
        PORTB = 0x10;
    }
    else if (readAD > 297 && readAD < 357){
        PORTB = 0x10;
        PORTA = 0x08;
    }
    else if (readAD > 461 && readAD < 521) {
        PORTB = 0x10;
        PORTA = 0x08;
        PORTC = 0x02;
    }
    else if (readAD > 584 && readAD < 644) {
        PORTB = 0x10;
        PORTA = 0x08;
        PORTC = 0x03;
    }
    }
    
    //ZerarFlags();)
}


void TestePWM(){
    pwmInit();
    pwmFrequency(60);
    
    for(i = 0; i < 100; i=i+10){
    pwmSet(i);
    Delay_ms(1);
    }
    Delay_ms(200);
    pwmSet(0);
    
    ZerarFlags();  
}


void TesteRTC(){
    lcdInit();
    rtcInit();       
    rtcSetDateTime();
  
    LimpaTela();
    
    for(i=0; i<10; i++){
    lcdCommand(0x80);
        lcdData(((rtcGetHours() / 10) % 10) + 48);
        lcdData((rtcGetHours() % 10) + 48);
        lcdData(58);
        lcdData(((rtcGetMinutes() / 10) % 10) + 48);
        lcdData((rtcGetMinutes() % 10) + 48);
        lcdData(58);
        lcdData(((rtcGetSeconds() / 10) % 10) + 48);
        lcdData((rtcGetSeconds() % 10) + 48);
    lcdCommand(0xC0);
        lcdData(((rtcGetDate() / 10) % 10) + 48);
        lcdData((rtcGetDate() % 10) + 48);
        lcdData(47);
        lcdData(((rtcGetMonth() / 10) % 10) + 48);
        lcdData((rtcGetMonth() % 10) + 48);
        lcdData(47);
        lcdData(((rtcGetYear() / 10) % 10) + 48);
        lcdData((rtcGetYear() % 10) + 48);
        
        Delay_ms(200);
    }
    
    ZerarFlags();    
    //MenuSwitch();
}


void TesteBAS(){
    TRISC = 0x7F;
    for(i=0x00; i<testbutt; i++){
        PORTC = 0x80;
        Delay_ms(200);
        PORTC = 0x00;
        Delay_ms(200);
    }    
    ZerarFlags();
}

void TesteLEDS(){
    TRISA = 0xF7;
    TRISB = 0xEF;
    TRISC = 0xFC;
    
    PORTB = 0x10;
    Delay_ms(100);
    PORTB = 0x00;
    PORTA = 0x08;
    Delay_ms(100);
    PORTA = 0x00;
    PORTC = 0x02;
    Delay_ms(100);
    PORTC = 0x00;
    PORTC = 0x01;
    Delay_ms(100);
    PORTC = 0x00;
    Delay_ms(100);
    
                PORTC = 0x01;
                PORTC = 0x03;
                delayms(10);
                PORTC = 0x02;
                PORTA = 0x08;
                delayms(10);
                PORTC = 0x00;
                PORTB = 0x10;
                delayms(10);
                PORTA = 0x00;
                delayms(10);
        
                PORTA = 0x08;
                delayms(10);
                PORTB = 0x00;
                PORTC = 0x02;
                delayms(10);
                PORTA = 0x00;
                PORTC = 0x03;
                delayms(10);
                PORTC = 0x01;
                delayms(10);
                PORTC = 0x00;
                delayms(10);
    
    for(i=0; i<3; i++){
    PORTC = 0x03;
    PORTA = 0x08;
    PORTB = 0x10;
    delayms(10);
    PORTC = 0x00;
    PORTA = 0x00;
    PORTB = 0x00;
    delayms(10);
    }
    ZerarFlags();
}

void MenuSwitch(){
    lcdCommand(0x80);
    for (i = 0; i < 16; i++) {
            lcdData(final1[i]);
    }
    lcdCommand(0xC0);
    for (i = 0; i < 16; i++) {
            lcdData(final2[i]);
    }  
}

void Menu(){
        
    lcdCommand(0x80);
    for (i = 0; i < 16; i++) {
            lcdData(teste1[i]);
    }
    lcdCommand(0xC0);
    for (i = 0; i < 16; i++) {
            lcdData(teste2[i]);
    }  
    delayms(60);
    lcdCommand(0x80);
    for (i = 0; i < 16; i++) {
            lcdData(teste3[i]);
    }
    lcdCommand(0xC0);
    for (i = 0; i < 16; i++) {
            lcdData(teste4[i]);
    } 
    delayms(60);
    MenuSwitch();
}


void KpRead(){
    
    TRISE   =   0xFF;
    //TRISB   =   0xFE;
    PORTB     =   0x00;
    
    ADCON0 = 0b00010101; //seleciona o canal 5 e liga o ad
	ADCON1 = 0b00001001; //AN5 � analogico, a referencia � baseada na fonte
	ADCON2 = 0b10101010; //FOSC /32, Alinhamento � direita e tempo de conv = 12 TAD

    read = adcRead();

    // --- Testa se os bot�es foram pressionados ---
    // Se foi pressionado, seta a respectiva flag
    if      (read > 256 && read < 316) butt05 = 0x01;
    else if (read > 488 && read < 548) butt04 = 0x01;
    else if (read > 664 && read < 724) butt03 = 0x01;
    else if (read > 849 && read < 909) butt02 = 0x01;
    else if (read > 994)               butt01 = 0x01;
    
    // --- Testa se os bot�es foram liberados ---
     if (read < 994  && butt01)                //Bot�o B0 solto e flag butt01 setada?
     {                                         //Sim...
         butt01 = 0x00;                        //Limpa flag butt01
         testbutt = 1;                         //Atualiza testbutt
         botao = 1;
         flagAux  = 0x01;                      //Seta flag auxiliar
     }
     if (read < 849  && butt02)                //Bot�o B1 solto e flag butt02 setada?
     {                                         //Sim...
         butt02 = 0x00;                        //Limpa flag butt02
         testbutt = 2;                         //Atualiza testbutt
         botao = 2;
         flagAux  = 0x01;                      //Seta flag auxiliar
     }
     if (read < 664  && butt03)                //Bot�o B2 solto e flag butt03 setada?
     {                                         //Sim...
         butt03 = 0x00;                        //Limpa flag butt03
         testbutt = 3;                         //Atualiza testbutt
         botao = 3;
         flagAux  = 0x01;                      //Seta flag auxiliar
     }
     if (read < 488  && butt04)                //Bot�o B3 solto e flag butt04 setada?
     {                                         //Sim...
         butt04 = 0x00;                        //Limpa flag butt04
         testbutt = 4;                         //Atualiza testbutt
         botao = 4;
         flagAux  = 0x01;                      //Seta flag auxiliar
     }
     if (read < 256  && butt05)                //Bot�o B4 solto e flag butt05 setada?
     {                                         //Sim...
         butt05 = 0x00;                        //Limpa flag butt05
         testbutt = 5;                         //Atualiza testbutt
         botao = 5;
         flagAux  = 0x01;                      //Seta flag auxiliar
     }

    /*
                Vin x 1024          Vin x 1024
 ResultADC = ----------------- = ----------------  =    Vin x 204.8
                Vrefh-Vref1             5



 *  Valores AD representados pelas teclas:
 *
 *  SW  |   Nome    |   Tens�o (V)  |   Digital     |  Usado
 *  ---------------------------------------------------------
 *  01  |   B0      |       5,000   |       1024    |   994~1024
 *  02  |   B1      |       4,292   |       879     |   849~909
 *  03  |   B2      |       3,390   |       694     |   664~724
 *  04  |   B3      |       2,532   |       518     |   488~548
 *  05  |   B4      |       1,379   |       286     |   256~316


 */
}

void Delay_ms(unsigned char i){

    unsigned char j;
    j = 0;

    for(i = 0; i < 255; i++) {
       for(j = 0; j < 255; j++);
       for(j = 0; j < 255; j++);
     }

}

void delayms(int t)
{
	volatile unsigned long l = 0;
	for(int i = 0; i < t; i++)
		for(l = 0; l < 6000; l++)
		{
		}
}

void LimpaTela(){
    lcdCommand(0x80);
    for (i = 0; i < 16; i++) {
            lcdData(limpaum[i]);
        }
    lcdCommand(0xC0);
        for (i = 0; i < 16; i++) {
            lcdData(limpadois[i]);
        }    
}

void ZerarFlags(){
    butt01 = 0x00;                    
    butt02 = 0x00;   
    butt03 = 0x00;                     
    butt04 = 0x00;   
    butt05 = 0x00;   
    flagAux = 0x00;
    botao = 0x00;
}