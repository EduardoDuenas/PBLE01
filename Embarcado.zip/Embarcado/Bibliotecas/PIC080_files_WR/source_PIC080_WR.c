/*
    Curso de Microcontroladores PIC WR Kits Channel

    Aula 80: Utilizando Teclado Matricial Anal�gico com PIC18

    Funcionamento: L� teclado anal�gico de 15 teclas pela entrada
    anal�gica 0 e converte para flags digitais

    MCU: PIC18F4520   Clock: 4MHz   Ciclo de M�quina: 1us



    Autor: Eng. Wagner Rambo   Data: Maio de 2016

    www.wrkits.com.br | youtube.com/user/canalwrkits | facebook.com/wrkits


    Equa��o de convers�o

                  Vin x 1024
    ResultADC = ---------------
                 Vrefh - Vrefl
*/


// --- Mapeamento de Hardware ---
#define LED  LATB0_bit                         //LED ligado ao pino RB0


// --- Prot�tipo das Fun��es Auxiliares ---
void keyboardRead();                           //Fun��o para leitura do teclado anal�gico



// --- Vari�vei Globais ---


int read     = 0x00;                           //Vari�vel para o conversor AD


unsigned char flag0 = 0x00,                    //Registrador auxiliar para indicar qual tecla pressionada (0 a 6)
              flag1 = 0x00,                    //Registrador auxiliar para indicar qual tecla pressionada (7 a 14)
              flag2 = 0x00,                    //Registrador auxiliar para indicar qual tecla foi liberada (0 a 6)
              flag3 = 0x00;                    //Registrador auxiliar para indicar qual tecla foi liberada (7 a 14)

char testbutt = 0x00;                          //Vari�vel para verificar n�mero da tecla pressionada.
char i = 0x00;                                 //Vari�vel para itera��es






// --- Flags do Usu�rio ---
#define  butt01   flag0.B0                     //Mnem�nico para flag0.B0
#define  butt02   flag0.B1                     //Mnem�nico para flag0.B1
#define  butt03   flag0.B2                     //Mnem�nico para flag0.B2
#define  butt04   flag0.B3                     //Mnem�nico para flag0.B3
#define  butt05   flag0.B4                     //Mnem�nico para flag0.B4
#define  butt06   flag0.B5                     //Mnem�nico para flag0.B5
#define  butt07   flag0.B6                     //Mnem�nico para flag0.B6
#define  butt08   flag0.B7                     //Mnem�nico para flag0.B7
#define  butt09   flag1.B0                     //Mnem�nico para flag1.B0
#define  butt10   flag1.B1                     //Mnem�nico para flag1.B1
#define  butt11   flag1.B2                     //Mnem�nico para flag1.B2
#define  butt12   flag1.B3                     //Mnem�nico para flag1.B3
#define  butt13   flag1.B4                     //Mnem�nico para flag1.B4
#define  butt14   flag1.B5                     //Mnem�nico para flag1.B5
#define  butt15   flag1.B6                     //Mnem�nico para flag1.B6

#define  flagAux  flag1.B7                     //Mnem�nico para flag1.B7


#define  SA       flag2.B0                     //Mnem�nico para flag2.B0
#define  SB       flag2.B1                     //Mnem�nico para flag2.B1
#define  SC       flag2.B2                     //Mnem�nico para flag2.B2
#define  S1       flag2.B3                     //Mnem�nico para flag2.B3
#define  S2       flag2.B4                     //Mnem�nico para flag2.B4
#define  S3       flag2.B5                     //Mnem�nico para flag2.B5
#define  S4       flag2.B6                     //Mnem�nico para flag2.B6
#define  S5       flag2.B7                     //Mnem�nico para flag2.B7
#define  S6       flag3.B0                     //Mnem�nico para flag3.B0
#define  S7       flag3.B1                     //Mnem�nico para flag3.B1
#define  S8       flag3.B2                     //Mnem�nico para flag3.B2
#define  S9       flag3.B3                     //Mnem�nico para flag3.B3
#define  S_ON     flag3.B4                     //Mnem�nico para flag3.B4
#define  S0       flag3.B5                     //Mnem�nico para flag3.B5
#define  S_OFF    flag3.B6                     //Mnem�nico para flag3.B6





// --- Fun��o Principal ---
void main()
{
     TRISA   = 0xFF;                           //Configura todo PORTA como entrada
     TRISB   = 0xFE;                           //Configura apenas RB0 como sa�da


     ADCON0  = 0x01;                           //Liga conversor AD
     ADCON1  = 0x0E;                           //Configura os pinos do PORTB como digitais, e RA0 (PORTA) como anal�gico
     LED    = 0x00;


     while(1)
     {

         keyboardRead();                       //Faz leitura do teclado

         if(flagAux)                           //flag auxiliar setada?
         {                                     //Sim...

             for(i = 0x00; i < testbutt; i++)  //Pisca LED o n�mero de vezes conforme tecla pressionada...
             {
                  LED = 0x01;
                  delay_ms(200);
                  LED = 0x00;
                  delay_ms(200);

             } //end for

             flag0   = 0x00;                   //Limpa toda flag0
             flag1   = 0x00;                   //Limpa toda flag1
             flag2   = 0x00;                   //Limpa toda flag2
             flag3   = 0x00;                   //Limpa toda flag3


         } //end if flagAux




     } //end while


} //end main




/*************************************************************************

      FUN��O PARA LEITURA DO TECLADO ANAL�GICO

Leu-se as respectivas tens�es geradas na sa�da do teclado, para cada bot�o
obtendo-se a seguinte tabela:


      VALORES AD REPRESENTADOS PELAS TECLAS:

       num |  Nome   | Tens�o (V) | Digital
      --------------------------------------
       01  |  SA     |  0,3731    |   76
       02  |  SB     |  0,5982    |  123
       03  |  SC     |  0,9241    |  189
       04  |  S1     |  1,2034    |  246
       05  |  S2     |  1,5951    |  327
       06  |  S3     |  2,0249    |  415
       07  |  S4     |  2,2933    |  470
       08  |  S5     |  2,5173    |  516
       09  |  S6     |  2,7613    |  566
       10  |  S7     |  2,9875    |  612
       11  |  S8     |  3,2140    |  658
       12  |  S9     |  3,6025    |  738
       13  |  S-ON   |  3,9401    |  807
       14  |  S0     |  4,2389    |  868
       15  |  S-OFF  |  4,5460    |  931

Os valores da �ltima coluna (Digital) s�o pertinentes � resolu��o ADC de 10 bits

 Tens�o M�xima    = 5V
 Valor M�ximo ADC = 1024

 Constante de Convers�o = 1024/5 = 204,8

 Multiplicou-se os valores da coluna Tens�o (V) pela constante de convers�o
 e arredondou-se para o inteiro mais pr�ximo, obtendo-se assim os limites
 de cada uma das 15 teclas.

*************************************************************************/
void keyboardRead()
{
     read = adc_Read(0);                       //Vari�vel para leitura recebe valor AD de AN0

     // --- Testa se os bot�es foram pressionados ---
     // Se foi pressionado, seta a respectiva flag
     if      (read >  56 && read <  96) butt01 = 0x01;
     else if (read > 103 && read < 143) butt02 = 0x01;
     else if (read > 169 && read < 209) butt03 = 0x01;
     else if (read > 226 && read < 266) butt04 = 0x01;
     else if (read > 307 && read < 347) butt05 = 0x01;
     else if (read > 395 && read < 435) butt06 = 0x01;
     else if (read > 450 && read < 490) butt07 = 0x01;
     else if (read > 496 && read < 536) butt08 = 0x01;
     else if (read > 546 && read < 586) butt09 = 0x01;
     else if (read > 592 && read < 632) butt10 = 0x01;
     else if (read > 638 && read < 678) butt11 = 0x01;
     else if (read > 718 && read < 758) butt12 = 0x01;
     else if (read > 787 && read < 827) butt13 = 0x01;
     else if (read > 848 && read < 888) butt14 = 0x01;
     else if (read > 911 && read < 951) butt15 = 0x01;

     // --- Testa se os bot�es foram liberados ---
     //
     if (read < 56 && butt01)                  //Bot�o SA solto e flag butt01 setada?
     {                                         //Sim...
         butt01 = 0x00;                        //Limpa flag butt01
         SA     = 0x01;                        //Seta flag SA
         testbutt = 0x01;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end SA
     if (read < 103 && butt02)                 //Bot�o SB solto e flag butt02 setada?
     {                                         //Sim...
         butt02 = 0x00;                        //Limpa flag butt02
         SB     = 0x01;                        //Seta flag SB
         testbutt = 2;                         //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S-X
     if (read < 169 && butt03)                 //Bot�o SB solto e flag butt03 setada?
     {                                         //Sim...
         butt03 = 0x00;                        //Limpa flag butt03
         SC     = 0x01;                        //Seta flag SC
         testbutt = 0x03;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S-TEM
     if (read < 226 && butt04)                 //Bot�o S1 solto e flag butt04 setada?
     {                                         //Sim...
         butt04 = 0x00;                        //Limpa flag butt04
         S1     = 0x01;                        //Seta flag S1
         testbutt = 0x04;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S1
     if (read < 307 && butt05)                 //Bot�o S2 solto e flag butt05 setada?
     {                                         //Sim...
         butt05 = 0x00;                        //Limpa flag butt05
         S2     = 0x01;                        //Seta flag S2
         testbutt = 0x05;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S2
     if (read < 395 && butt06)                 //Bot�o S3 solto e flag butt06 setada?
     {                                         //Sim...
         butt06 = 0x00;                        //Limpa flag butt06
         S3     = 0x01;                        //Seta flag S3
         testbutt = 0x06;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S3
     if (read < 450 && butt07)                 //Bot�o S4 solto e flag butt07 setada?
     {                                         //Sim...
         butt07 = 0x00;                        //Limpa flag butt07
         S4     = 0x01;                        //Seta flag S4
         testbutt = 0x07;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S4
     if (read < 496 && butt08)                 //Bot�o S5 solto e flag butt08 setada?
     {                                         //Sim...
         butt08 = 0x00;                        //Limpa flag butt08
         S5     = 0x01;                        //Seta flag S5
         testbutt = 0x08;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S5
     if (read < 546 && butt09)                 //Bot�o S6 solto e flag butt09 setada?
     {                                         //Sim...
         butt09 = 0x00;                        //Limpa flag butt09
         S6     = 0x01;                        //Seta flag S6
         testbutt = 0x09;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S6
     if (read < 592 && butt10)                 //Bot�o S7 solto e flag butt10 setada?
     {                                         //Sim...
         butt10 = 0x00;                        //Limpa flag butt10
         S7     = 0x01;                        //Seta flag S7
         testbutt = 0x0A;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S7
     if (read < 638 && butt11)                 //Bot�o S8 solto e flag butt11 setada?
     {                                         //Sim...
         butt11 = 0x00;                        //Limpa flag butt11
         S8     = 0x01;                        //Seta flag S8
         testbutt = 0x0B;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S8
     if (read < 718 && butt12)                 //Bot�o S9 solto e flag butt12 setada?
     {                                         //Sim...
         butt12 = 0x00;                        //Limpa flag butt12
         S9     = 0x01;                        //Seta flag S9
         testbutt = 0x0C;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S9
     if (read < 787 && butt13)                 //Bot�o S-LIG solto e flag butt13 setada?
     {                                         //Sim...
         butt13 = 0x00;                        //Limpa flag butt13
         S_ON   = 0x01;                        //Seta flag S_LIG
         testbutt = 0x0D;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S_LIG
     if (read < 848 && butt14)                 //Bot�o S0 solto e flag butt14 setada?
     {                                         //Sim...
         butt14 = 0x00;                        //Limpa flag butt14
         S0     = 0x01;                        //Seta flag S0
         testbutt = 0x0E;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S0
     if (read < 911 && butt15)                 //Bot�o S-LIG solto e flag butt15 setada?
     {                                         //Sim...
         butt15 = 0x00;                        //Limpa flag butt15
         S_OFF  = 0x01;                        //Seta flag S_CAN
         testbutt = 0x0F;                      //Atualiza testbutt
         flagAux  = 0x01;                      //Seta flag auxiliar
     } //end S_CAN


} //end keyboardRead